package interfaces;

public interface AnimalEstimacao {
    void brincar();
    void levarPassear();
}
