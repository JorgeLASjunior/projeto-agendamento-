package interfaces;

public interface AnimalDomesticado {
    void alimentar();
    void levarVeterinario();
    void chamarVeterinario();
}
