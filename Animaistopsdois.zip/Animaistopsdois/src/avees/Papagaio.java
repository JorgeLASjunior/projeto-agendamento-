package avees;

import java.util.ArrayList;
import java.util.List;

public class Papagaio extends Ave {
    private int idade;
    private List<String> palavrasConhecidas;

    public Papagaio(String nome) {
        super(nome);
        this.idade = 0;
        this.palavrasConhecidas = new ArrayList<>();
    }

    @Override
    public String voar() {
        System.out.println("Papagaio voando alto");
        return "Papagaio voando alto";
    }

    @Override
    public String emitirSom() {
        System.out.println("Papagaio falando papapa");
        return "Papagaio falando papapa";
    }

    public void repetirFrase(String frase) {
        System.out.println("Papagaio repetindo: " + frase);
    }

    public void dançar() {
        System.out.println("Papagaio dançando");
    }

    public void comer() {
        System.out.println("Papagaio comendo");
    }

    public void dormir() {
        System.out.println("Papagaio dormindo");
    }

    public void brincar(String brinquedo) {
        System.out.println("Papagaio brincando com " + brinquedo);
    }

    public void aprenderNovaPalavra(String palavra) {
        palavrasConhecidas.add(palavra);
        System.out.println("Papagaio aprendeu uma nova palavra: " + palavra);
    }

    public void mostrarPalavrasConhecidas() {
        System.out.println("Palavras conhecidas: " + String.join(", ", palavrasConhecidas));
    }

    public void limparPenas() {
        System.out.println("Papagaio limpando suas penas");
    }

    public void imitarSom(String som) {
        System.out.println("Papagaio imitando: " + som);
    }

    public void socializar(String outroPapagaio) {
        System.out.println("Papagaio socializando com: " + outroPapagaio);
    }

    // Getters e setters
    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }
}
