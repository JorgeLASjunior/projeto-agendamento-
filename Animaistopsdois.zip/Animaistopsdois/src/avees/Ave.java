package avees;

public abstract class Ave {
    private String nome;

    public Ave(String nome) {
        this.nome = nome;
    }

    public abstract String voar();

    public abstract String emitirSom();

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
