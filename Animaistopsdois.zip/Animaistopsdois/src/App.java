import avees.Papagaio;
import mamiferos.Cachorro;
import mamiferos.Gato;
import mamiferos.Cavalo;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class App {

    // Caminho do arquivo para salvar os dados dos animais
    private static final String FILE_PATH = "C:\\agendamento\\animais.txt";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Object> animais = new ArrayList<>();

        // Carregar animais do arquivo
        carregarAnimais(animais);

        boolean continuar = true;

        // Início do sistema
        System.out.println("\nDeseja entrar no sistema? (sim ou nao)");
        String entrada = scanner.nextLine();

        // Loop principal do sistema
        while (continuar) {

            // Menu principal
            if (entrada.equalsIgnoreCase("sim")) {
                System.out.println("---------------------------");
                System.out.println("Opções:");
                System.out.println("1 - Adicionar animal");
                System.out.println("2 - Ver animal");
                System.out.println("3 - Ver todos os animais");
                System.out.println("4 - Excluir animal");
                System.out.println("5 - Sair");
                System.out.println("---------------------------");

                int opcao = scanner.nextInt();
                scanner.nextLine(); 

                switch (opcao) {
                    case 1:         
                        // Escolhendo tipo de animal e nome do mesmo
                        System.out.println("Qual tipo de animal deseja adicionar?");
                        System.out.println("1 - Papagaio\n2 - Cachorro\n3 - Gato\n4 - Cavalo");
                        int tipoAnimal = scanner.nextInt();
                        scanner.nextLine(); 

                        System.out.println("Informe o nome do animal:");
                        String nomeAnimal = scanner.nextLine();

                        // Adicionando animal à lista
                        switch (tipoAnimal) {
                            case 1:
                                animais.add(new Papagaio(nomeAnimal));
                                break;
                            case 2:
                                System.out.println("Informe o tamanho do cachorro:");
                                String tamanho = scanner.nextLine();
                                System.out.println("Informe a raça do cachorro:");
                                String raca = scanner.nextLine();
                                animais.add(new Cachorro(nomeAnimal, tamanho, raca));
                                break;
                            case 3:
                                System.out.println("Informe a raça do gato:");
                                String racaGato = scanner.nextLine();
                                animais.add(new Gato(nomeAnimal, racaGato));
                                break;
                            case 4:
                                animais.add(new Cavalo(nomeAnimal));
                                break;
                            default:
                                System.out.println("Opção de animal inválida.");
                                break;
                        }
                        System.out.println("Animal adicionado com sucesso!");
                        // Salvar animais no arquivo
                        salvarAnimais(animais);
                        break;
                    case 2:
                        // Ver dados do animal específico
                        System.out.println("Qual animal deseja ver? (Digite o número correspondente)");
                        listarAnimaisNumerados(animais);

                        int escolhaVer = scanner.nextInt();
                        scanner.nextLine(); 

                        if (escolhaVer > 0 && escolhaVer <= animais.size()) {
                            Object animal = animais.get(escolhaVer - 1);
                            mostrarDetalhesAnimal(animal);
                        } else {
                            System.out.println("Opção inválida.");
                        }
                        break;
                    case 3: 
                        // Lista com todos os animais e seus dados
                        System.out.println("Todos os animais:");
                        for (Object animal : animais) {
                            mostrarDetalhesAnimal(animal);
                            System.out.println("-------------");
                        }
                        break;
                    case 4:
                        // Excluir animal
                        System.out.println("Qual animal deseja excluir? (Digite o número correspondente)");
                        listarAnimaisNumerados(animais);

                        int escolhaExcluir = scanner.nextInt();
                        scanner.nextLine(); 

                        if (escolhaExcluir > 0 && escolhaExcluir <= animais.size()) {
                            Object animalExcluir = animais.get(escolhaExcluir - 1);
                            animais.remove(animalExcluir);
                            System.out.println("Animal removido com sucesso!");
                            // Salvar animais no arquivo
                            salvarAnimais(animais);
                        } else {
                            System.out.println("Opção inválida.");
                        }
                        break;
                    case 5:
                        // Fechamento do sistema
                        continuar = false;
                        break;
                    default:
                        System.out.println("Opção inválida.");
                        break;
                }
            } else if (entrada.equalsIgnoreCase("nao")) {
                continuar = false;
            } else {
                System.out.println("Resposta inválida. Por favor, digite 'sim' ou 'nao'.");
            }
        }

        scanner.close(); 
        System.out.println("Sistema encerrado.");
    }

    /**
     * Salva a lista de animais no arquivo especificado.
     *
     * @param animais a lista de animais a serem salvos
     */
    private static void salvarAnimais(List<Object> animais) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_PATH))) {
            for (Object animal : animais) {
                writer.write(serializeAnimal(animal));
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Carrega a lista de animais do arquivo especificado.
     *
     * @param animais a lista onde os animais carregados serão adicionados
     */
    private static void carregarAnimais(List<Object> animais) {
        File file = new File(FILE_PATH);

        if (file.exists()) {
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String linha;
                while ((linha = reader.readLine()) != null) {
                    animais.add(deserializeAnimal(linha));
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Serializa um objeto animal em uma string.
     *
     * @param animal o objeto animal a ser serializado
     * @return a representação em string do objeto animal
     */
    private static String serializeAnimal(Object animal) {
        if (animal instanceof Papagaio) {
            return "Papagaio:" + ((Papagaio) animal).getNome();
        } else if (animal instanceof Cachorro) {
            Cachorro cachorro = (Cachorro) animal;
            return "Cachorro:" + cachorro.getNome() + "," + cachorro.getTamanho() + "," + cachorro.getRaca();
        } else if (animal instanceof Gato) {
            Gato gato = (Gato) animal;
            return "Gato:" + gato.getNome() + "," + gato.getRaca();
        } else if (animal instanceof Cavalo) {
            return "Cavalo:" + ((Cavalo) animal).getNome();
        } else {
            return "";
        }
    }

    /**
     * Desserializa uma string em um objeto animal.
     *
     * @param linha a representação em string do objeto animal
     * @return o objeto animal desserializado
     */
    private static Object deserializeAnimal(String linha) {
        String[] partes = linha.split(":");
        String tipo = partes[0];
        String[] atributos = partes[1].split(",");

        switch (tipo) {
            case "Papagaio":
                return new Papagaio(atributos[0]);
            case "Cachorro":
                return new Cachorro(atributos[0], atributos[1], atributos[2]);
            case "Gato":
                return new Gato(atributos[0], atributos[1]);
            case "Cavalo":
                return new Cavalo(atributos[0]);
            default:
                return null;
        }
    }

    /**
     * Mostra os detalhes de um objeto animal.
     *
     * @param animal o objeto animal cujos detalhes serão mostrados
     */
    private static void mostrarDetalhesAnimal(Object animal) {
        if (animal instanceof Papagaio) {
            Papagaio papagaio = (Papagaio) animal;
            System.out.println("Papagaio:");
            System.out.println("Nome: " + papagaio.getNome());
            System.out.println("Idade: " + papagaio.getIdade() + " anos");
            System.out.println("Som: " + papagaio.emitirSom());
            papagaio.mostrarPalavrasConhecidas();
            papagaio.dançar();
            papagaio.comer();
            papagaio.dormir();
            papagaio.brincar("bola");
            papagaio.limparPenas();
            papagaio.imitarSom("cachorro latindo");
            papagaio.socializar("outro papagaio");
        } else if (animal instanceof Cachorro) {
            Cachorro cachorro = (Cachorro) animal;
            System.out.println("Cachorro:");
            System.out.println("Nome: " + cachorro.getNome());
            System.out.println("Tamanho: " + cachorro.getTamanho());
            System.out.println("Raça: " + cachorro.getRaca());
            System.out.println("Idade: " + cachorro.getIdade() + " anos");
            System.out.println("Som: " + cachorro.emitirSom());
            cachorro.brincar(null);
            cachorro.correr();
            cachorro.dormir();
            cachorro.comer();
            cachorro.fazerTruque("dar a pata");
            cachorro.protegerCasa();
            cachorro.cavar();
        } else if (animal instanceof Gato) {
            Gato gato = (Gato) animal;
            System.out.println("Gato:");
            System.out.println("Nome: " + gato.getNome());
            System.out.println("Raça: " + gato.getRaca());
            System.out.println("Idade: " + gato.getIdade() + " anos");
            System.out.println("Som: " + gato.emitirSom());
            gato.brincar(null);
            gato.comer();
            gato.dormir();
            gato.comer();
            gato.escalar();
            gato.arranhar();
            gato.ronronar();
        } else if (animal instanceof Cavalo) {
            Cavalo cavalo = (Cavalo) animal;
            System.out.println("Cavalo:");
            System.out.println("Nome: " + cavalo.getNome());
            System.out.println("Idade: " + cavalo.getIdade() + " anos");
            System.out.println("Som: " + cavalo.emitirSom());
            cavalo.galopar();
            cavalo.correr();
            cavalo.comer();
            cavalo.dormir();
            cavalo.pastar();
            cavalo.pastar();
            cavalo.saltarObstaculo();
        }
    }
    
    /**
     * Retorna o nome do animal.
     *
     * @param animal o objeto animal cujo nome será retornado
     * @return o nome do animal
     */
    private static String getAnimalNome(Object animal) {
        if (animal instanceof Papagaio) {
            return "Papagaio: " + ((Papagaio) animal).getNome();
        } else if (animal instanceof Cachorro) {
            return "Cachorro: " + ((Cachorro) animal).getNome();
        } else if (animal instanceof Gato) {
            return "Gato: " + ((Gato) animal).getNome();
        } else if (animal instanceof Cavalo) {
            return "Cavalo: " + ((Cavalo) animal).getNome();
        } else {
            return "Desconhecido";
        }
    }

    /**
     * Lista os animais numerados para escolha.
     *
     * @param animais a lista de animais a ser listada
     */
    private static void listarAnimaisNumerados(List<Object> animais) {
        for (int i = 0; i < animais.size(); i++) {
            System.out.println(i + 1 + " - " + getAnimalNome(animais.get(i)));
        }
    }
}
