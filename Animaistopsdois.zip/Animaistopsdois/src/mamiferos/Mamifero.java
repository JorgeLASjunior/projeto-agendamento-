package mamiferos;

import animall.Animal;

public abstract class Mamifero extends Animal {
    private int idade;

    public Mamifero(String nome) {
        super(nome);
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public abstract String amamentar();
}
