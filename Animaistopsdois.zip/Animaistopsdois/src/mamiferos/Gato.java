package mamiferos;

public class Gato extends Mamifero {
    private String raca;
    private int idade;
    private String corPelo;

    public Gato(String nome, String raca) {
        super(nome);
        this.raca = raca;
        this.idade = 0;
        this.corPelo = "";
    }

    @Override
    public String emitirSom() {
        System.out.println("Gato miando miau");
        return "Gato miando miau";
    }

    public void brincar(String brinquedo) {
        System.out.println("Gato brincando com " + brinquedo);
    }

    public void correr() {
        System.out.println("Gato correndo");
    }

    public void dormir() {
        System.out.println("Gato dormindo");
    }

    public void comer() {
        System.out.println("Gato comendo");
    }

    public void escalar() {
        System.out.println("Gato escalando");
    }

    public void arranhar() {
        System.out.println("Gato arranhando");
    }

    public void ronronar() {
        System.out.println("Gato ronronando");
    }

    // Getters e setters
    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getCorPelo() {
        return corPelo;
    }

    public void setCorPelo(String corPelo) {
        this.corPelo = corPelo;
    }

    @Override
    public String amamentar() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'amamentar'");
    }
}
