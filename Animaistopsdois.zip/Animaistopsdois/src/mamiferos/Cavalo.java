package mamiferos;

public class Cavalo extends Mamifero {
    private int idade;
    private String corPelo;

    public Cavalo(String nome) {
        super(nome);
        this.idade = 0;
        this.corPelo = "";
    }

    @Override
    public String emitirSom() {
        System.out.println("Cavalo relinchando hininnin");
        return "Cavalo relinchando hininnin";
    }

    public void galopar() {
        System.out.println("Cavalo galopando");
    }

    public void correr() {
        System.out.println("Cavalo correndo");
    }

    public void comer() {
        System.out.println("Cavalo comendo");
    }

    public void dormir() {
        System.out.println("Cavalo dormindo");
    }

    public void pular() {
        System.out.println("Cavalo pulando");
    }

    public void pastar() {
        System.out.println("Cavalo pastando");
    }

    public void saltarObstaculo() {
        System.out.println("Cavalo saltando obstáculo");
    }

    // Getters e setters
    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getCorPelo() {
        return corPelo;
    }

    public void setCorPelo(String corPelo) {
        this.corPelo = corPelo;
    }

    @Override
    public String amamentar() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'amamentar'");
    }

    public void puxarCarroca() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'puxarCarroca'");
    }
}
