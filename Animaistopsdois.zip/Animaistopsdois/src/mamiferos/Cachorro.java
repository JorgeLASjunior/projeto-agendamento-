package mamiferos;

public class Cachorro extends Mamifero {
    private String tamanho;
    private String raca;
    private int idade;
    private String corPelo;

    public Cachorro(String nome, String tamanho, String raca) {
        super(nome);
        this.tamanho = tamanho;
        this.raca = raca;
        this.idade = 0;
        this.corPelo = "";
    }

    @Override
    public String emitirSom() {
        System.out.println("Cachorro latindo auau");
        return "Cachorro latindo auau";
    }

    public void brincar(String brinquedo) {
        System.out.println("Cachorro brincando com " + brinquedo);
    }

    public void correr() {
        System.out.println("Cachorro correndo");
    }

    public void dormir() {
        System.out.println("Cachorro dormindo");
    }

    public void comer() {
        System.out.println("Cachorro comendo");
    }

    public void fazerTruque(String truque) {
        System.out.println("Cachorro fazendo truque: " + truque);
    }

    public void protegerCasa() {
        System.out.println("Cachorro protegendo a casa");
    }

    public void cavar() {
        System.out.println("Cachorro cavando");
    }

    // Getters e setters
    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public String getRaca() {
        return raca;
    }

    public void setRaca(String raca) {
        this.raca = raca;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getCorPelo() {
        return corPelo;
    }

    public void setCorPelo(String corPelo) {
        this.corPelo = corPelo;
    }

    @Override
    public String amamentar() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'amamentar'");
    }
}
